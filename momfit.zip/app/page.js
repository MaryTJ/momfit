import FitnessAppStreaming from "@/components/FitnessAppStreaming";

export default function Home() {
  return <FitnessAppStreaming />;
}